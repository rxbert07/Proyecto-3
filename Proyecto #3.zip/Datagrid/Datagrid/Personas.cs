﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datagrid
{
    internal class Personas
    {
        public int id, edad;
        public double deuda;
        public string nombre, apellido, cedula, condicion, sexo, estado;

        public Personas(int id, string cedula, string nombre, string apellido, int edad, bool enfermo, string sexo, string condicion, double deuda) 
        { 
            this.id = id;
            this.cedula = cedula;
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
            this.sexo = sexo;
            this.condicion = condicion;
            this.deuda = deuda;

            if (enfermo)
            {
                this.estado = "Enfermo";
            }
            else
            {
                this.estado = "Sano";
            }
        }
    }
}
