using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace Datagrid
{
    public partial class FormPaginaMain : Form
    {

        public FormPaginaMain()
        {
            InitializeComponent();
            IniciarCombobox();
            
        }

        List<Personas> listaPacientesEnfermos = new List<Personas>();
        List<Personas> listaPacientesSanos = new List<Personas>();
        List<Personas> pacientesFiltrados = new List<Personas>();
        int contadorId = 1;
        int TotalPacientes, contadorClickFiltro;
        int NPacientesEnfermos = 0;
        int NPacientesSanos = 0;
        int NPacientesTotal = 0;





        private void IniciarCombobox()
        {
            CbSexoFiltro.SelectedIndex = 0;
            CbEdadFiltro.SelectedIndex = 0;
            CbEstadoFiltro.SelectedIndex = 0;
        }

        private void BtnIngresar_Click(object sender, EventArgs e)
        {
            // Asi se verifica que todos los campos esten llenos antes de ingresar a una persona
            if (!verificarCamposLlenosIngresar())
            {
                bool Enfermo = false;

                if (CbEnfermoSi.Checked)
                {
                    Enfermo = true;
                }

                //Personas(int id, string cedula, string nombre, string apellido, int edad, bool enfermo, string sexo, string condicion, double deuda)
                Personas paciente = new Personas(contadorId, TbCedula.Text, TbNombre.Text, TbApellido.Text, Convert.ToInt32(TbEdad.Text), Enfermo, CbSexo.Text, TbCondicion.Text, Convert.ToDouble(TbDeuda.Text));
                contadorId++;

                if (paciente.estado == "Enfermo")
                {
                    listaPacientesEnfermos.Add(paciente);
                    TotalPacientes++;
                }
                else
                {
                    listaPacientesSanos.Add(paciente);
                    TotalPacientes++;
                }
                ActualizarContador();
                limpiarCamposIngresar();
                ActualizarContadoresTextBox();

            }
        }

        private void ActualizarContador()
        {
            NPacientesEnfermos = listaPacientesEnfermos.Count;
            NPacientesSanos = listaPacientesSanos.Count;
            NPacientesTotal = NPacientesEnfermos + NPacientesSanos;
        }

        private void ActualizarContadoresTextBox()
        {
            TbPacientesActualesTotal.Text = NPacientesTotal.ToString();
            TbPacientesSanosTotal.Text = NPacientesSanos.ToString();
            TbPacientesEnfermosTotal.Text = NPacientesEnfermos.ToString();
        }

        private bool verificarCamposLlenosIngresar()
        {
            if (String.IsNullOrWhiteSpace(TbCedula.Text) || String.IsNullOrWhiteSpace(TbNombre.Text) || String.IsNullOrWhiteSpace(TbApellido.Text) || String.IsNullOrWhiteSpace(TbEdad.Text) || String.IsNullOrWhiteSpace(TbCondicion.Text) || String.IsNullOrWhiteSpace(TbDeuda.Text) || CbSexo.SelectedItem == null || (!CbEnfermoSi.Checked && !CbEnfermoNo.Checked))
            {
                MessageBox.Show("Verifique que todos los campos esten llenos");
                return true;
            }
            return false;
        }


        private void TbCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite solo d�gitos num�ricos y la tecla de retroceso
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true; // Ignora el evento de la tecla si no es un n�mero o backspace
            }

            // Solo permite la tecla de retroceso si hay mas de 8 caracteres
            if (TbCedula.Text.Length >= 8 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void TbEdad_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite solo d�gitos num�ricos y la tecla de retroceso
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true; // Ignora el evento de la tecla si no es un n�mero o backspace
            }

            // Solo permite a tecla de retroceso si hay mas de 2 caracteres
            if (TbEdad.Text.Length >= 2 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
        private void TbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {


            // Permite solo letras y la tecla de retroceso
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true; // Ignora el evento de la tecla si no es una letra o backspace
            }

            // Solo permite la tecla de retroceso si hay mas de 20 caracteres
            if (TbNombre.Text.Length >= 20 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void TbApellido_KeyPress(object sender, KeyPressEventArgs e)
        {


            // Permite solo letras y la tecla de retroceso
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true; // Ignora el evento de la tecla si no es una letra o backspace
            }

            // Solo permite la tecla de retroceso si hay mas de 20 caracteres
            if (TbApellido.Text.Length >= 20 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void TbCondicion_KeyPress(object sender, KeyPressEventArgs e)
        {

            // Permite solo letras y la tecla de retroceso
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Space)
            {
                e.Handled = true; // Ignora el evento de la tecla si no es una letra o backspace
            }

            // Solo permite la tecla de retroceso si hay mas de 30 caracteres
            if (TbCondicion.Text.Length >= 30 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void TbDeuda_KeyPress(object sender, KeyPressEventArgs e)
        {
            bool esPunto = e.KeyChar == '.';

            // Verifica si ya existe una coma en el texto para evitar m�ltiples puntos
            bool yaExistePunto = TbDeuda.Text.Contains(".");

            // Permite solo d�gitos num�ricos, la tecla de retroceso y el punto
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && (!esPunto || yaExistePunto))
            {
                e.Handled = true; // Ignora el evento de la tecla si no es un n�mero, backspace o el punto
            }

            // Solo permite la tecla de retroceso si hay mas de 15 caracteres
            if (TbDeuda.Text.Length >= 15 && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }


        private void BtnMostrar_Click(object sender, EventArgs e)
        {
            TablaPacientes.Rows.Clear();

            for (int id = 1; id <= TotalPacientes; id++)
            {
                // Busca en la lista de pacientes enfermos
                foreach (Personas paciente in listaPacientesEnfermos)
                {
                    if (id == paciente.id)
                    {
                        TablaPacientes.Rows.Add(paciente.id, paciente.cedula, paciente.nombre, paciente.apellido, paciente.sexo, paciente.edad, paciente.estado, paciente.condicion, paciente.deuda);
                        break; // Sale del bucle una vez encontrado el paciente
                    }
                }

                // Busca en la lista de pacientes sanos
                foreach (Personas paciente in listaPacientesSanos)
                {
                    if (id == paciente.id)
                    {
                        TablaPacientes.Rows.Add(paciente.id, paciente.cedula, paciente.nombre, paciente.apellido, paciente.sexo, paciente.edad, paciente.estado, paciente.condicion, paciente.deuda);
                        break; // Sale del bucle una vez encontrado el paciente
                    }
                }
            }

        }


        private void limpiarCamposIngresar()
        {
            TbCedula.Clear();
            TbNombre.Clear();
            TbApellido.Clear();
            TbEdad.Clear();
            TbCondicion.Clear();
            TbDeuda.Clear();
            CbEnfermoSi.Checked = false;
            CbEnfermoNo.Checked = false;
            CbSexo.SelectedItem = null;
        }

        private void CbEnfermoSi_MouseClick(object sender, MouseEventArgs e)
        {
            CbEnfermoNo.Checked = false;
        }

        private void CbEnfermoNo_MouseClick(object sender, MouseEventArgs e)
        {
            CbEnfermoSi.Checked = false;
        }

        private void BtnLimpiar_Click(object sender, EventArgs e)
        {

            if (CbListPacientesEnfermos.Checked)
            {
                listaPacientesEnfermos.Clear();
            }

            if (CbListPacientesSanos.Checked)
            {
                listaPacientesSanos.Clear();
            }

            if (CbLimpiarTablaPacientes.Checked)
            {
                TablaPacientes.Rows.Clear();
            }

            CbListPacientesEnfermos.Checked = false;
            CbListPacientesSanos.Checked = false;
            CbLimpiarTablaPacientes.Checked = false;
        }

        private void BtnFiltrar_Click(object sender, EventArgs e)
        {
            int edadFiltro = 100;
            String SexoSeleccionado = CbSexoFiltro.Text;
            String estadoSeleccionado = CbEstadoFiltro.Text;


            if (NPacientesTotal > 0)
            {
                TablaPacientes.Rows.Clear(); // Limpia las filas existentes para aplicar el filtro
                
                if (CbEdadFiltro.Text != "Todos")
                {
                    edadFiltro = Convert.ToInt32(CbEdadFiltro);
                }
                else
                {
                    edadFiltro = 100;
                }


                if (contadorClickFiltro > 0)
                {
                    pacientesFiltrados.Clear(); // Limpia la lista de pacientes filtrados
                }

                 switch (CbEstadoFiltro.Text)
                {
                    case "Enfermos":
                        pacientesFiltrados = filtrarLista(listaPacientesEnfermos, edadFiltro);
                        break;
                    case "Sanos":
                        pacientesFiltrados = filtrarLista(listaPacientesSanos, edadFiltro);
                        break;
                    default:
                        pacientesFiltrados = JuntarListas(listaPacientesEnfermos, listaPacientesSanos, edadFiltro);
                        break;
                }
                
                
                /*pacientesFiltrados = listaPacientesEnfermos.Concat(listaPacientesSanos).ToList();

                filtrarSexoSeleccionado(SexoSeleccionado, pacientesFiltrados);
                filtrarEstado(estadoSeleccionado, pacientesFiltrados);
                filtrarEdad(edadFiltro, pacientesFiltrados);
                */

                foreach (Personas paciente in pacientesFiltrados)
                {
                    TablaPacientes.Rows.Add(paciente.id, paciente.cedula, paciente.nombre, paciente.apellido,
                        paciente.sexo, paciente.edad, paciente.estado, paciente.condicion, paciente.deuda);
                    break;
                }

                contadorClickFiltro++;
            }
            else
            {
                MessageBox.Show("Primero Agregue a un Paciente");
            }
        }

        private List<Personas> filtrarLista(List<Personas> listaPacientes, int edadFiltro)
        {
            // Inicializa la variable para la edad, manejando el caso "Todos"
            if (listaPacientes.Count > 0)
            {
                // Filtra la lista usando LINQ
                foreach (Personas paciente in listaPacientes)
                {
                    if (CbSexoFiltro.Text != "Todos")
                    {
                        var listaFiltrada = listaPacientes.Where(paciente =>
                        (paciente.sexo == CbSexoFiltro.Text) &&
                        (CbEdadFiltro.Text == "Todos" || paciente.edad <= edadFiltro)).ToList();

                        return listaFiltrada;
                    }
                    else
                    {
                        var listaFiltrada = listaPacientes.Where(paciente => paciente.edad <= edadFiltro).ToList();
                        return listaFiltrada;
                    }
                }
            }
            return listaPacientes;
            

            
        }


            private List<Personas> JuntarListas(List<Personas> listaPacientes1, List<Personas> listaPacientes2, int edadFiltro)
        {
            List<Personas> listaAux = filtrarLista(listaPacientes1, edadFiltro);
            List<Personas> listaAux1 = filtrarLista(listaPacientes2, edadFiltro);

            foreach (Personas paciente in listaAux1)
            {
                listaAux.Add(paciente);
            }

            return listaAux;
        }
        
        


        // FILTROS
        // IEnumerable<Personas> pacientesFiltrados = listaTotalPacientes.Where(paciente => )
        
        private void filtrarSexoSeleccionado(string sexoSeleccionado, List<Personas> listaTotalPacientes)
        {
            if (sexoSeleccionado == "Todos")
            {
                pacientesFiltrados = listaTotalPacientes.Where(paciente => paciente.sexo == "F" || paciente.sexo == "M").ToList();
            }
            else
            {
                if (sexoSeleccionado == "M")
                {
                    pacientesFiltrados = listaTotalPacientes.Where(paciente => paciente.sexo == "M").ToList();
                }
                else
                {
                    pacientesFiltrados = listaTotalPacientes.Where(paciente => paciente.sexo == "F").ToList();
                }
            }
        }

        private void filtrarEstado(string estadoSeleccionado, List<Personas> listaTotalPacientes)
        {
            if (estadoSeleccionado == "Todos")
            {
                pacientesFiltrados = listaTotalPacientes.Where(paciente => paciente.estado == "Enfermo" || paciente.sexo == "Sano").ToList();
            }
            else
            {
                if (estadoSeleccionado == "Enfermo")
                {
                    pacientesFiltrados = listaTotalPacientes.Where(paciente => paciente.estado == "Enfermo").ToList();
                }
                else
                {
                    pacientesFiltrados = listaTotalPacientes.Where(paciente => paciente.estado == "Sano").ToList();
                }
            }
        }

        private void filtrarEdad(int edadSeleccionada, List<Personas> listaTotalPacientes)
        {
                pacientesFiltrados = listaTotalPacientes.Where(paciente => paciente.edad <= edadSeleccionada).ToList(); 
        }

    }
}
