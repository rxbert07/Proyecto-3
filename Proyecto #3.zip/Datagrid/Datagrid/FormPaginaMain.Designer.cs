﻿namespace Datagrid
{
    partial class FormPaginaMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPaginaMain));
            TablaPacientes = new DataGridView();
            DgId = new DataGridViewTextBoxColumn();
            DgCedula = new DataGridViewTextBoxColumn();
            DgNombre = new DataGridViewTextBoxColumn();
            DgColApellido = new DataGridViewTextBoxColumn();
            DgSexo = new DataGridViewTextBoxColumn();
            DgEdad = new DataGridViewTextBoxColumn();
            DgEstado = new DataGridViewTextBoxColumn();
            DgCondicion = new DataGridViewTextBoxColumn();
            DgDeuda = new DataGridViewTextBoxColumn();
            BtnIngresar = new Button();
            CbSexo = new ComboBox();
            TbCedula = new TextBox();
            TbNombre = new TextBox();
            TbEdad = new TextBox();
            TbCondicion = new TextBox();
            TbDeuda = new TextBox();
            CbEnfermoSi = new CheckBox();
            LbCedula = new Label();
            LbNombre = new Label();
            LbEdad = new Label();
            LbCondicion = new Label();
            LbDeuda = new Label();
            BtnMostrarList = new Button();
            PanelSup = new Panel();
            PbLogo = new PictureBox();
            TituloPaginaMain = new Label();
            PanelIzquierdo = new Panel();
            TbApellido = new TextBox();
            LbApellido = new Label();
            LbEnfermo = new Label();
            CbEnfermoNo = new CheckBox();
            LbIngresarDatos = new Label();
            LbIngresarPacientes = new Label();
            LbSexo = new Label();
            CbSexoFiltro = new ComboBox();
            LbFiltrar = new Label();
            LbTituloPacientes = new Label();
            LbSexoFiltro = new Label();
            LbEstadoFiltro = new Label();
            CbEstadoFiltro = new ComboBox();
            LbEdadFiltro = new Label();
            CbEdadFiltro = new ComboBox();
            CbListPacientesEnfermos = new CheckBox();
            LbLimpiarListEnfermos = new Label();
            LbListPacientesSanos = new Label();
            LbLimpiar = new Label();
            CbListPacientesSanos = new CheckBox();
            CbLimpiarTablaPacientes = new CheckBox();
            LbTablaPacientes = new Label();
            BtnLimpiar = new Button();
            BtnFiltrar = new Button();
            LbPacientes = new Label();
            TbPacientesEnfermosTotal = new TextBox();
            TbPacientesActualesTotal = new TextBox();
            TbPacientesSanosTotal = new TextBox();
            LbPacientesActuales = new Label();
            LbTotalPacEnfermos = new Label();
            LbEnfermos = new Label();
            LbPacientesSanos = new Label();
            LbSanos = new Label();
            ((System.ComponentModel.ISupportInitialize)TablaPacientes).BeginInit();
            PanelSup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PbLogo).BeginInit();
            PanelIzquierdo.SuspendLayout();
            SuspendLayout();
            // 
            // TablaPacientes
            // 
            TablaPacientes.AllowUserToAddRows = false;
            TablaPacientes.AllowUserToDeleteRows = false;
            TablaPacientes.BackgroundColor = Color.Teal;
            TablaPacientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            TablaPacientes.Columns.AddRange(new DataGridViewColumn[] { DgId, DgCedula, DgNombre, DgColApellido, DgSexo, DgEdad, DgEstado, DgCondicion, DgDeuda });
            TablaPacientes.GridColor = Color.FromArgb(0, 192, 192);
            TablaPacientes.Location = new Point(248, 460);
            TablaPacientes.Name = "TablaPacientes";
            TablaPacientes.ReadOnly = true;
            TablaPacientes.RowHeadersVisible = false;
            TablaPacientes.RowHeadersWidth = 51;
            TablaPacientes.Size = new Size(761, 267);
            TablaPacientes.TabIndex = 0;
            // 
            // DgId
            // 
            DgId.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            DgId.HeaderText = "ID";
            DgId.MinimumWidth = 6;
            DgId.Name = "DgId";
            DgId.ReadOnly = true;
            DgId.Width = 53;
            // 
            // DgCedula
            // 
            DgCedula.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            DgCedula.HeaderText = "Cedula";
            DgCedula.MinimumWidth = 6;
            DgCedula.Name = "DgCedula";
            DgCedula.ReadOnly = true;
            DgCedula.Width = 84;
            // 
            // DgNombre
            // 
            DgNombre.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            DgNombre.HeaderText = "Nombre";
            DgNombre.MinimumWidth = 6;
            DgNombre.Name = "DgNombre";
            DgNombre.ReadOnly = true;
            DgNombre.Width = 93;
            // 
            // DgColApellido
            // 
            DgColApellido.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            DgColApellido.HeaderText = "Apellido";
            DgColApellido.MinimumWidth = 6;
            DgColApellido.Name = "DgColApellido";
            DgColApellido.ReadOnly = true;
            DgColApellido.Width = 95;
            // 
            // DgSexo
            // 
            DgSexo.HeaderText = "Sexo";
            DgSexo.MinimumWidth = 6;
            DgSexo.Name = "DgSexo";
            DgSexo.ReadOnly = true;
            DgSexo.Width = 55;
            // 
            // DgEdad
            // 
            DgEdad.HeaderText = "Edad";
            DgEdad.MinimumWidth = 6;
            DgEdad.Name = "DgEdad";
            DgEdad.ReadOnly = true;
            DgEdad.Width = 55;
            // 
            // DgEstado
            // 
            DgEstado.HeaderText = "Estado";
            DgEstado.MinimumWidth = 6;
            DgEstado.Name = "DgEstado";
            DgEstado.ReadOnly = true;
            DgEstado.Width = 70;
            // 
            // DgCondicion
            // 
            DgCondicion.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            DgCondicion.HeaderText = "Condicion";
            DgCondicion.MinimumWidth = 6;
            DgCondicion.Name = "DgCondicion";
            DgCondicion.ReadOnly = true;
            DgCondicion.Width = 105;
            // 
            // DgDeuda
            // 
            DgDeuda.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            DgDeuda.HeaderText = "Deuda";
            DgDeuda.MinimumWidth = 6;
            DgDeuda.Name = "DgDeuda";
            DgDeuda.ReadOnly = true;
            DgDeuda.Width = 82;
            // 
            // BtnIngresar
            // 
            BtnIngresar.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            BtnIngresar.Location = new Point(46, 595);
            BtnIngresar.Name = "BtnIngresar";
            BtnIngresar.Size = new Size(122, 41);
            BtnIngresar.TabIndex = 1;
            BtnIngresar.Text = "Ingresar";
            BtnIngresar.UseVisualStyleBackColor = true;
            BtnIngresar.Click += BtnIngresar_Click;
            // 
            // CbSexo
            // 
            CbSexo.DropDownStyle = ComboBoxStyle.DropDownList;
            CbSexo.FormattingEnabled = true;
            CbSexo.Items.AddRange(new object[] { "M", "F" });
            CbSexo.Location = new Point(93, 379);
            CbSexo.Name = "CbSexo";
            CbSexo.Size = new Size(75, 28);
            CbSexo.TabIndex = 2;
            // 
            // TbCedula
            // 
            TbCedula.Location = new Point(12, 112);
            TbCedula.Name = "TbCedula";
            TbCedula.Size = new Size(180, 27);
            TbCedula.TabIndex = 3;
            TbCedula.KeyPress += TbCedula_KeyPress;
            // 
            // TbNombre
            // 
            TbNombre.Location = new Point(12, 180);
            TbNombre.Name = "TbNombre";
            TbNombre.Size = new Size(180, 27);
            TbNombre.TabIndex = 4;
            TbNombre.KeyPress += TbNombre_KeyPress;
            // 
            // TbEdad
            // 
            TbEdad.Location = new Point(14, 303);
            TbEdad.Name = "TbEdad";
            TbEdad.Size = new Size(180, 27);
            TbEdad.TabIndex = 5;
            TbEdad.KeyPress += TbEdad_KeyPress;
            // 
            // TbCondicion
            // 
            TbCondicion.Location = new Point(14, 443);
            TbCondicion.Multiline = true;
            TbCondicion.Name = "TbCondicion";
            TbCondicion.Size = new Size(178, 74);
            TbCondicion.TabIndex = 6;
            TbCondicion.KeyPress += TbCondicion_KeyPress;
            // 
            // TbDeuda
            // 
            TbDeuda.Location = new Point(12, 545);
            TbDeuda.Name = "TbDeuda";
            TbDeuda.Size = new Size(180, 27);
            TbDeuda.TabIndex = 7;
            TbDeuda.TextAlign = HorizontalAlignment.Right;
            TbDeuda.KeyPress += TbDeuda_KeyPress;
            // 
            // CbEnfermoSi
            // 
            CbEnfermoSi.AutoSize = true;
            CbEnfermoSi.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            CbEnfermoSi.ForeColor = Color.White;
            CbEnfermoSi.Location = new Point(109, 336);
            CbEnfermoSi.Name = "CbEnfermoSi";
            CbEnfermoSi.Size = new Size(47, 26);
            CbEnfermoSi.TabIndex = 8;
            CbEnfermoSi.Text = "Si";
            CbEnfermoSi.UseVisualStyleBackColor = true;
            CbEnfermoSi.MouseClick += CbEnfermoSi_MouseClick;
            // 
            // LbCedula
            // 
            LbCedula.AutoSize = true;
            LbCedula.Font = new Font("Bell MT", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbCedula.ForeColor = Color.White;
            LbCedula.Location = new Point(12, 87);
            LbCedula.Name = "LbCedula";
            LbCedula.Size = new Size(65, 22);
            LbCedula.TabIndex = 9;
            LbCedula.Text = "Cedula";
            // 
            // LbNombre
            // 
            LbNombre.AutoSize = true;
            LbNombre.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            LbNombre.ForeColor = Color.White;
            LbNombre.Location = new Point(12, 155);
            LbNombre.Name = "LbNombre";
            LbNombre.Size = new Size(75, 22);
            LbNombre.TabIndex = 10;
            LbNombre.Text = "Nombre";
            // 
            // LbEdad
            // 
            LbEdad.AutoSize = true;
            LbEdad.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            LbEdad.ForeColor = Color.White;
            LbEdad.Location = new Point(12, 278);
            LbEdad.Name = "LbEdad";
            LbEdad.Size = new Size(51, 22);
            LbEdad.TabIndex = 11;
            LbEdad.Text = "Edad";
            // 
            // LbCondicion
            // 
            LbCondicion.AutoSize = true;
            LbCondicion.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            LbCondicion.ForeColor = Color.White;
            LbCondicion.Location = new Point(12, 418);
            LbCondicion.Name = "LbCondicion";
            LbCondicion.Size = new Size(90, 22);
            LbCondicion.TabIndex = 13;
            LbCondicion.Text = "Condicion";
            // 
            // LbDeuda
            // 
            LbDeuda.AutoSize = true;
            LbDeuda.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            LbDeuda.ForeColor = Color.White;
            LbDeuda.Location = new Point(12, 520);
            LbDeuda.Name = "LbDeuda";
            LbDeuda.Size = new Size(62, 22);
            LbDeuda.TabIndex = 14;
            LbDeuda.Text = "Deuda";
            // 
            // BtnMostrarList
            // 
            BtnMostrarList.BackColor = Color.Teal;
            BtnMostrarList.Font = new Font("Bell MT", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnMostrarList.Location = new Point(559, 338);
            BtnMostrarList.Name = "BtnMostrarList";
            BtnMostrarList.Size = new Size(158, 41);
            BtnMostrarList.TabIndex = 15;
            BtnMostrarList.Text = "Mostrar Lista";
            BtnMostrarList.UseVisualStyleBackColor = false;
            BtnMostrarList.Click += BtnMostrar_Click;
            // 
            // PanelSup
            // 
            PanelSup.BackColor = Color.DarkCyan;
            PanelSup.Controls.Add(PbLogo);
            PanelSup.Controls.Add(TituloPaginaMain);
            PanelSup.Dock = DockStyle.Top;
            PanelSup.Location = new Point(0, 0);
            PanelSup.Name = "PanelSup";
            PanelSup.Size = new Size(1009, 79);
            PanelSup.TabIndex = 16;
            // 
            // PbLogo
            // 
            PbLogo.Image = Properties.Resources.logo1;
            PbLogo.Location = new Point(12, 12);
            PbLogo.Name = "PbLogo";
            PbLogo.Size = new Size(74, 57);
            PbLogo.SizeMode = PictureBoxSizeMode.StretchImage;
            PbLogo.TabIndex = 17;
            PbLogo.TabStop = false;
            // 
            // TituloPaginaMain
            // 
            TituloPaginaMain.AutoSize = true;
            TituloPaginaMain.FlatStyle = FlatStyle.Popup;
            TituloPaginaMain.Font = new Font("Stencil", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TituloPaginaMain.Location = new Point(92, 18);
            TituloPaginaMain.Name = "TituloPaginaMain";
            TituloPaginaMain.Size = new Size(582, 40);
            TituloPaginaMain.TabIndex = 17;
            TituloPaginaMain.Text = "Clinica LE CANCER COMPANY S.A";
            // 
            // PanelIzquierdo
            // 
            PanelIzquierdo.BackColor = Color.FromArgb(0, 64, 64);
            PanelIzquierdo.Controls.Add(TbApellido);
            PanelIzquierdo.Controls.Add(LbApellido);
            PanelIzquierdo.Controls.Add(LbEnfermo);
            PanelIzquierdo.Controls.Add(CbEnfermoNo);
            PanelIzquierdo.Controls.Add(LbIngresarDatos);
            PanelIzquierdo.Controls.Add(LbIngresarPacientes);
            PanelIzquierdo.Controls.Add(LbCedula);
            PanelIzquierdo.Controls.Add(LbEdad);
            PanelIzquierdo.Controls.Add(TbCedula);
            PanelIzquierdo.Controls.Add(BtnIngresar);
            PanelIzquierdo.Controls.Add(TbCondicion);
            PanelIzquierdo.Controls.Add(LbDeuda);
            PanelIzquierdo.Controls.Add(LbSexo);
            PanelIzquierdo.Controls.Add(TbDeuda);
            PanelIzquierdo.Controls.Add(LbCondicion);
            PanelIzquierdo.Controls.Add(CbSexo);
            PanelIzquierdo.Controls.Add(LbNombre);
            PanelIzquierdo.Controls.Add(TbNombre);
            PanelIzquierdo.Controls.Add(CbEnfermoSi);
            PanelIzquierdo.Controls.Add(TbEdad);
            PanelIzquierdo.Dock = DockStyle.Left;
            PanelIzquierdo.Location = new Point(0, 79);
            PanelIzquierdo.Name = "PanelIzquierdo";
            PanelIzquierdo.Size = new Size(249, 648);
            PanelIzquierdo.TabIndex = 17;
            // 
            // TbApellido
            // 
            TbApellido.Location = new Point(14, 245);
            TbApellido.Name = "TbApellido";
            TbApellido.Size = new Size(180, 27);
            TbApellido.TabIndex = 23;
            TbApellido.KeyPress += TbApellido_KeyPress;
            // 
            // LbApellido
            // 
            LbApellido.AutoSize = true;
            LbApellido.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            LbApellido.ForeColor = Color.White;
            LbApellido.Location = new Point(12, 220);
            LbApellido.Name = "LbApellido";
            LbApellido.Size = new Size(77, 22);
            LbApellido.TabIndex = 22;
            LbApellido.Text = "Apellido";
            // 
            // LbEnfermo
            // 
            LbEnfermo.AutoSize = true;
            LbEnfermo.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            LbEnfermo.ForeColor = Color.White;
            LbEnfermo.Location = new Point(14, 336);
            LbEnfermo.Name = "LbEnfermo";
            LbEnfermo.Size = new Size(79, 22);
            LbEnfermo.TabIndex = 21;
            LbEnfermo.Text = "Enfermo";
            // 
            // CbEnfermoNo
            // 
            CbEnfermoNo.AutoSize = true;
            CbEnfermoNo.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            CbEnfermoNo.ForeColor = Color.White;
            CbEnfermoNo.Location = new Point(162, 336);
            CbEnfermoNo.Name = "CbEnfermoNo";
            CbEnfermoNo.Size = new Size(56, 26);
            CbEnfermoNo.TabIndex = 20;
            CbEnfermoNo.Text = "No";
            CbEnfermoNo.UseVisualStyleBackColor = true;
            CbEnfermoNo.MouseClick += CbEnfermoNo_MouseClick;
            // 
            // LbIngresarDatos
            // 
            LbIngresarDatos.AutoSize = true;
            LbIngresarDatos.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            LbIngresarDatos.ForeColor = Color.White;
            LbIngresarDatos.Location = new Point(3, 50);
            LbIngresarDatos.Name = "LbIngresarDatos";
            LbIngresarDatos.Size = new Size(238, 20);
            LbIngresarDatos.TabIndex = 19;
            LbIngresarDatos.Text = "Ingrese todos los datos requeridos";
            // 
            // LbIngresarPacientes
            // 
            LbIngresarPacientes.AutoSize = true;
            LbIngresarPacientes.FlatStyle = FlatStyle.Flat;
            LbIngresarPacientes.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbIngresarPacientes.ForeColor = SystemColors.ButtonHighlight;
            LbIngresarPacientes.Location = new Point(36, 12);
            LbIngresarPacientes.Name = "LbIngresarPacientes";
            LbIngresarPacientes.Size = new Size(168, 25);
            LbIngresarPacientes.TabIndex = 18;
            LbIngresarPacientes.Text = "Ingresar pacientes";
            // 
            // LbSexo
            // 
            LbSexo.AutoSize = true;
            LbSexo.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            LbSexo.ForeColor = Color.White;
            LbSexo.Location = new Point(14, 381);
            LbSexo.Name = "LbSexo";
            LbSexo.Size = new Size(49, 22);
            LbSexo.TabIndex = 12;
            LbSexo.Text = "Sexo";
            // 
            // CbSexoFiltro
            // 
            CbSexoFiltro.DropDownStyle = ComboBoxStyle.DropDownList;
            CbSexoFiltro.FormattingEnabled = true;
            CbSexoFiltro.Items.AddRange(new object[] { "Todos", "M", "F" });
            CbSexoFiltro.Location = new Point(400, 190);
            CbSexoFiltro.Name = "CbSexoFiltro";
            CbSexoFiltro.Size = new Size(82, 28);
            CbSexoFiltro.TabIndex = 20;
            // 
            // LbFiltrar
            // 
            LbFiltrar.AutoSize = true;
            LbFiltrar.Font = new Font("Bell MT", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbFiltrar.ForeColor = Color.Black;
            LbFiltrar.Location = new Point(303, 148);
            LbFiltrar.Name = "LbFiltrar";
            LbFiltrar.Size = new Size(179, 28);
            LbFiltrar.TabIndex = 20;
            LbFiltrar.Text = "Filtrar busqueda";
            // 
            // LbTituloPacientes
            // 
            LbTituloPacientes.AutoSize = true;
            LbTituloPacientes.Font = new Font("Bell MT", 19.8000011F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            LbTituloPacientes.ForeColor = Color.Black;
            LbTituloPacientes.Location = new Point(483, 100);
            LbTituloPacientes.Name = "LbTituloPacientes";
            LbTituloPacientes.Size = new Size(285, 39);
            LbTituloPacientes.TabIndex = 21;
            LbTituloPacientes.Text = "Lista de Pacientes";
            // 
            // LbSexoFiltro
            // 
            LbSexoFiltro.AutoSize = true;
            LbSexoFiltro.Font = new Font("Bell MT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbSexoFiltro.ForeColor = Color.Black;
            LbSexoFiltro.Location = new Point(314, 192);
            LbSexoFiltro.Name = "LbSexoFiltro";
            LbSexoFiltro.Size = new Size(53, 24);
            LbSexoFiltro.TabIndex = 20;
            LbSexoFiltro.Text = "Sexo";
            // 
            // LbEstadoFiltro
            // 
            LbEstadoFiltro.AutoSize = true;
            LbEstadoFiltro.Font = new Font("Bell MT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbEstadoFiltro.ForeColor = Color.Black;
            LbEstadoFiltro.Location = new Point(314, 245);
            LbEstadoFiltro.Name = "LbEstadoFiltro";
            LbEstadoFiltro.Size = new Size(71, 24);
            LbEstadoFiltro.TabIndex = 22;
            LbEstadoFiltro.Text = "Estado";
            // 
            // CbEstadoFiltro
            // 
            CbEstadoFiltro.DropDownStyle = ComboBoxStyle.DropDownList;
            CbEstadoFiltro.FormattingEnabled = true;
            CbEstadoFiltro.Items.AddRange(new object[] { "Todos", "Enfermos", "Sanos" });
            CbEstadoFiltro.Location = new Point(400, 244);
            CbEstadoFiltro.Name = "CbEstadoFiltro";
            CbEstadoFiltro.Size = new Size(82, 28);
            CbEstadoFiltro.TabIndex = 23;
            // 
            // LbEdadFiltro
            // 
            LbEdadFiltro.AutoSize = true;
            LbEdadFiltro.Font = new Font("Bell MT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbEdadFiltro.ForeColor = Color.Black;
            LbEdadFiltro.Location = new Point(314, 297);
            LbEdadFiltro.Name = "LbEdadFiltro";
            LbEdadFiltro.Size = new Size(55, 24);
            LbEdadFiltro.TabIndex = 24;
            LbEdadFiltro.Text = "Edad";
            // 
            // CbEdadFiltro
            // 
            CbEdadFiltro.DropDownStyle = ComboBoxStyle.DropDownList;
            CbEdadFiltro.FormattingEnabled = true;
            CbEdadFiltro.Items.AddRange(new object[] { "Todos", "5", "10", "15", "20", "25", "30", "35", "40", "45", "50" });
            CbEdadFiltro.Location = new Point(400, 293);
            CbEdadFiltro.Name = "CbEdadFiltro";
            CbEdadFiltro.Size = new Size(82, 28);
            CbEdadFiltro.TabIndex = 25;
            // 
            // CbListPacientesEnfermos
            // 
            CbListPacientesEnfermos.AutoSize = true;
            CbListPacientesEnfermos.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            CbListPacientesEnfermos.ForeColor = Color.White;
            CbListPacientesEnfermos.Location = new Point(968, 196);
            CbListPacientesEnfermos.Name = "CbListPacientesEnfermos";
            CbListPacientesEnfermos.Size = new Size(18, 17);
            CbListPacientesEnfermos.TabIndex = 24;
            CbListPacientesEnfermos.UseVisualStyleBackColor = true;
            // 
            // LbLimpiarListEnfermos
            // 
            LbLimpiarListEnfermos.AutoSize = true;
            LbLimpiarListEnfermos.Font = new Font("Bell MT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbLimpiarListEnfermos.ForeColor = Color.Black;
            LbLimpiarListEnfermos.Location = new Point(645, 191);
            LbLimpiarListEnfermos.Name = "LbLimpiarListEnfermos";
            LbLimpiarListEnfermos.Size = new Size(260, 24);
            LbLimpiarListEnfermos.TabIndex = 26;
            LbLimpiarListEnfermos.Text = "Lista de Pacientes Enfermos";
            // 
            // LbListPacientesSanos
            // 
            LbListPacientesSanos.AutoSize = true;
            LbListPacientesSanos.Font = new Font("Bell MT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbListPacientesSanos.ForeColor = Color.Black;
            LbListPacientesSanos.Location = new Point(645, 234);
            LbListPacientesSanos.Name = "LbListPacientesSanos";
            LbListPacientesSanos.Size = new Size(227, 24);
            LbListPacientesSanos.TabIndex = 27;
            LbListPacientesSanos.Text = "Lista de Pacientes Sanos";
            // 
            // LbLimpiar
            // 
            LbLimpiar.AutoSize = true;
            LbLimpiar.Font = new Font("Bell MT", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbLimpiar.ForeColor = Color.Black;
            LbLimpiar.Location = new Point(764, 148);
            LbLimpiar.Name = "LbLimpiar";
            LbLimpiar.Size = new Size(92, 28);
            LbLimpiar.TabIndex = 28;
            LbLimpiar.Text = "Limpiar";
            // 
            // CbListPacientesSanos
            // 
            CbListPacientesSanos.AutoSize = true;
            CbListPacientesSanos.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            CbListPacientesSanos.ForeColor = Color.White;
            CbListPacientesSanos.Location = new Point(968, 238);
            CbListPacientesSanos.Name = "CbListPacientesSanos";
            CbListPacientesSanos.Size = new Size(18, 17);
            CbListPacientesSanos.TabIndex = 29;
            CbListPacientesSanos.UseVisualStyleBackColor = true;
            // 
            // CbLimpiarTablaPacientes
            // 
            CbLimpiarTablaPacientes.AutoSize = true;
            CbLimpiarTablaPacientes.Font = new Font("Bell MT", 10.8F, FontStyle.Bold);
            CbLimpiarTablaPacientes.ForeColor = Color.White;
            CbLimpiarTablaPacientes.Location = new Point(968, 282);
            CbLimpiarTablaPacientes.Name = "CbLimpiarTablaPacientes";
            CbLimpiarTablaPacientes.Size = new Size(18, 17);
            CbLimpiarTablaPacientes.TabIndex = 30;
            CbLimpiarTablaPacientes.UseVisualStyleBackColor = true;
            // 
            // LbTablaPacientes
            // 
            LbTablaPacientes.AutoSize = true;
            LbTablaPacientes.Font = new Font("Bell MT", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbTablaPacientes.ForeColor = Color.Black;
            LbTablaPacientes.Location = new Point(645, 277);
            LbTablaPacientes.Name = "LbTablaPacientes";
            LbTablaPacientes.Size = new Size(178, 24);
            LbTablaPacientes.TabIndex = 31;
            LbTablaPacientes.Text = "Tabla de Pacientes";
            // 
            // BtnLimpiar
            // 
            BtnLimpiar.BackColor = Color.Teal;
            BtnLimpiar.Font = new Font("Bell MT", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnLimpiar.Location = new Point(894, 338);
            BtnLimpiar.Name = "BtnLimpiar";
            BtnLimpiar.Size = new Size(92, 41);
            BtnLimpiar.TabIndex = 32;
            BtnLimpiar.Text = "Limpiar";
            BtnLimpiar.UseVisualStyleBackColor = false;
            BtnLimpiar.Click += BtnLimpiar_Click;
            // 
            // BtnFiltrar
            // 
            BtnFiltrar.BackColor = Color.Teal;
            BtnFiltrar.Font = new Font("Bell MT", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnFiltrar.Location = new Point(314, 338);
            BtnFiltrar.Name = "BtnFiltrar";
            BtnFiltrar.Size = new Size(92, 41);
            BtnFiltrar.TabIndex = 33;
            BtnFiltrar.Text = "Filtrar";
            BtnFiltrar.UseVisualStyleBackColor = false;
            BtnFiltrar.Click += BtnFiltrar_Click;
            // 
            // LbPacientes
            // 
            LbPacientes.AutoSize = true;
            LbPacientes.Font = new Font("Bell MT", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbPacientes.ForeColor = Color.Black;
            LbPacientes.Location = new Point(257, 404);
            LbPacientes.Name = "LbPacientes";
            LbPacientes.Size = new Size(137, 22);
            LbPacientes.TabIndex = 34;
            LbPacientes.Text = "Total Pacientes";
            // 
            // TbPacientesEnfermosTotal
            // 
            TbPacientesEnfermosTotal.Location = new Point(655, 415);
            TbPacientesEnfermosTotal.Name = "TbPacientesEnfermosTotal";
            TbPacientesEnfermosTotal.ReadOnly = true;
            TbPacientesEnfermosTotal.Size = new Size(62, 27);
            TbPacientesEnfermosTotal.TabIndex = 24;
            // 
            // TbPacientesActualesTotal
            // 
            TbPacientesActualesTotal.Location = new Point(400, 415);
            TbPacientesActualesTotal.Name = "TbPacientesActualesTotal";
            TbPacientesActualesTotal.ReadOnly = true;
            TbPacientesActualesTotal.Size = new Size(62, 27);
            TbPacientesActualesTotal.TabIndex = 36;
            // 
            // TbPacientesSanosTotal
            // 
            TbPacientesSanosTotal.Location = new Point(924, 410);
            TbPacientesSanosTotal.Name = "TbPacientesSanosTotal";
            TbPacientesSanosTotal.ReadOnly = true;
            TbPacientesSanosTotal.Size = new Size(62, 27);
            TbPacientesSanosTotal.TabIndex = 38;
            // 
            // LbPacientesActuales
            // 
            LbPacientesActuales.AutoSize = true;
            LbPacientesActuales.Font = new Font("Bell MT", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbPacientesActuales.ForeColor = Color.Black;
            LbPacientesActuales.Location = new Point(288, 426);
            LbPacientesActuales.Name = "LbPacientesActuales";
            LbPacientesActuales.Size = new Size(79, 22);
            LbPacientesActuales.TabIndex = 39;
            LbPacientesActuales.Text = "Actuales";
            // 
            // LbTotalPacEnfermos
            // 
            LbTotalPacEnfermos.AutoSize = true;
            LbTotalPacEnfermos.Font = new Font("Bell MT", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbTotalPacEnfermos.ForeColor = Color.Black;
            LbTotalPacEnfermos.Location = new Point(503, 404);
            LbTotalPacEnfermos.Name = "LbTotalPacEnfermos";
            LbTotalPacEnfermos.Size = new Size(137, 22);
            LbTotalPacEnfermos.TabIndex = 40;
            LbTotalPacEnfermos.Text = "Total Pacientes";
            // 
            // LbEnfermos
            // 
            LbEnfermos.AutoSize = true;
            LbEnfermos.Font = new Font("Bell MT", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbEnfermos.ForeColor = Color.Black;
            LbEnfermos.Location = new Point(529, 426);
            LbEnfermos.Name = "LbEnfermos";
            LbEnfermos.Size = new Size(87, 22);
            LbEnfermos.TabIndex = 41;
            LbEnfermos.Text = "Enfermos";
            // 
            // LbPacientesSanos
            // 
            LbPacientesSanos.AutoSize = true;
            LbPacientesSanos.Font = new Font("Bell MT", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbPacientesSanos.ForeColor = Color.Black;
            LbPacientesSanos.Location = new Point(768, 404);
            LbPacientesSanos.Name = "LbPacientesSanos";
            LbPacientesSanos.Size = new Size(137, 22);
            LbPacientesSanos.TabIndex = 42;
            LbPacientesSanos.Text = "Total Pacientes";
            // 
            // LbSanos
            // 
            LbSanos.AutoSize = true;
            LbSanos.Font = new Font("Bell MT", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbSanos.ForeColor = Color.Black;
            LbSanos.Location = new Point(815, 426);
            LbSanos.Name = "LbSanos";
            LbSanos.Size = new Size(57, 22);
            LbSanos.TabIndex = 43;
            LbSanos.Text = "Sanos";
            // 
            // FormPaginaMain
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Azure;
            ClientSize = new Size(1009, 727);
            Controls.Add(LbSanos);
            Controls.Add(LbPacientesSanos);
            Controls.Add(LbEnfermos);
            Controls.Add(LbTotalPacEnfermos);
            Controls.Add(LbPacientesActuales);
            Controls.Add(TbPacientesSanosTotal);
            Controls.Add(TbPacientesActualesTotal);
            Controls.Add(TbPacientesEnfermosTotal);
            Controls.Add(LbPacientes);
            Controls.Add(BtnFiltrar);
            Controls.Add(BtnLimpiar);
            Controls.Add(LbTablaPacientes);
            Controls.Add(CbLimpiarTablaPacientes);
            Controls.Add(CbListPacientesSanos);
            Controls.Add(LbLimpiar);
            Controls.Add(LbListPacientesSanos);
            Controls.Add(LbLimpiarListEnfermos);
            Controls.Add(CbListPacientesEnfermos);
            Controls.Add(CbEdadFiltro);
            Controls.Add(LbEdadFiltro);
            Controls.Add(CbEstadoFiltro);
            Controls.Add(LbEstadoFiltro);
            Controls.Add(LbSexoFiltro);
            Controls.Add(LbTituloPacientes);
            Controls.Add(LbFiltrar);
            Controls.Add(CbSexoFiltro);
            Controls.Add(PanelIzquierdo);
            Controls.Add(PanelSup);
            Controls.Add(BtnMostrarList);
            Controls.Add(TablaPacientes);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "FormPaginaMain";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "LE CANCER COMPANY S.A";
            ((System.ComponentModel.ISupportInitialize)TablaPacientes).EndInit();
            PanelSup.ResumeLayout(false);
            PanelSup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)PbLogo).EndInit();
            PanelIzquierdo.ResumeLayout(false);
            PanelIzquierdo.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView TablaPacientes;
        private Button BtnIngresar;
        private ComboBox CbSexo;
        private TextBox TbCedula;
        private TextBox TbNombre;
        private TextBox TbEdad;
        private TextBox TbCondicion;
        private TextBox TbDeuda;
        private CheckBox CbEnfermoSi;
        private Label LbCedula;
        private Label LbNombre;
        private Label LbEdad;
        private Label LbCondicion;
        private Label LbDeuda;
        private Button BtnMostrarList;
        private Panel PanelSup;
        private Label TituloPaginaMain;
        private PictureBox PbLogo;
        private Panel PanelIzquierdo;
        private Label LbIngresarDatos;
        private Label LbIngresarPacientes;
        private ComboBox CbSexoFiltro;
        private Label LbFiltrar;
        private Label LbTituloPacientes;
        private Label LbSexo;
        private Label LbSexoFiltro;
        private Label LbEstadoFiltro;
        private ComboBox CbEstadoFiltro;
        private Label LbEdadFiltro;
        private ComboBox CbEdadFiltro;
        private Label LbEnfermo;
        private CheckBox CbEnfermoNo;
        private TextBox TbApellido;
        private Label LbApellido;
        private CheckBox CbListPacientesEnfermos;
        private Label LbLimpiarListEnfermos;
        private Label LbListPacientesSanos;
        private Label LbLimpiar;
        private CheckBox CbListPacientesSanos;
        private CheckBox CbLimpiarTablaPacientes;
        private Label LbTablaPacientes;
        private Button BtnLimpiar;
        private Button BtnFiltrar;
        private DataGridViewTextBoxColumn DgId;
        private DataGridViewTextBoxColumn DgCedula;
        private DataGridViewTextBoxColumn DgNombre;
        private DataGridViewTextBoxColumn DgColApellido;
        private DataGridViewTextBoxColumn DgSexo;
        private DataGridViewTextBoxColumn DgEdad;
        private DataGridViewTextBoxColumn DgEstado;
        private DataGridViewTextBoxColumn DgCondicion;
        private DataGridViewTextBoxColumn DgDeuda;
        private Label LbPacientes;
        private TextBox TbPacientesEnfermosTotal;
        private TextBox TbPacientesActualesTotal;
        private TextBox TbPacientesSanosTotal;
        private Label LbPacientesActuales;
        private Label LbTotalPacEnfermos;
        private Label LbEnfermos;
        private Label LbPacientesSanos;
        private Label LbSanos;
    }
}
